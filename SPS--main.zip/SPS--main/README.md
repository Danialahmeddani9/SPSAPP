# SPS 
This system is developed to solve the problem of parking and other vehicle-related services like finding workshops or service stations in an emergency.
                                            Modules studied at undergraduate level

 My name is Danial Ahmed and I have a good knowledge in Programming. I make an application in my undergraduation named as SPS Station and Car parking (CarLay). 
All the documents of this application is attached with the source code.
I use Different scripting language in this application. It was my final year project.



